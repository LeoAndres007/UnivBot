# coding=utf8
"""
search.py - UnivBot Web Search Module
Copyright 2008-9, Sean B. Palmer, inamidst.com
Copyright 2012, Edward Powell, embolalia.net
Licensed under the Eiffel Forum License 2.

http://UnivBot.dftba.net
"""
from __future__ import unicode_literals

import re
from UnivBot import web
from UnivBot.module import commands, example
import json
import sys
import time


def google_ajax(query):
    """Search using AjaxSearch, and return its JSON."""
    uri = 'http://ajax.googleapis.com/ajax/services/search/web'
    args = '?v=1.0&safe=off&q=' + query
    bytes = web.get(uri + args)
    return json.loads(bytes)


def google_search(query):
    results = google_ajax(query)
    try:
        return results['responseData']['results'][0]['unescapedUrl']
    except IndexError:
        return None
    except TypeError:
        return False


def google_count(query):
    results = google_ajax(query)
    if not 'responseData' in results:
        return '0'
    if not 'cursor' in results['responseData']:
        return '0'
    if not 'estimatedResultCount' in results['responseData']['cursor']:
        return '0'
    return results['responseData']['cursor']['estimatedResultCount']


def formatnumber(n):
    """Format a number with beautiful commas."""
    parts = list(str(n))
    for i in range((len(parts) - 3), 0, -3):
        parts.insert(i, ',')
    return ''.join(parts)


@commands('g', 'google')
@example('%google jabón')
def g(bot, trigger):
    """Busca por resultados en Google."""
    query = trigger.group(2)
    if not query:
        return bot.reply('¿Que deseas que Googlee?')
    uri = google_search(query)
    if uri:
        bot.reply(uri)
        #bot.memory['last_seen_url'][trigger.sender] = uri
    elif uri is False:
        bot.reply("Ha ocurrido un error mientras se buscaban resultados.")
    else:
        bot.reply("No se han encontrado resultados para '%s'." % query)


@commands('gc', 'googlec')
@example('%gc extrapolate')
def gc(bot, trigger):
    """Devuelve el número de resultados de una búsqueda en Google."""
    query = trigger.group(2)
    if not query:
        return bot.reply('¿Contar resultados de que?')
    num = formatnumber(google_count(query))
    bot.say(query + ': ' + num)

r_query = re.compile(
    r'\+?"[^"\\]*(?:\\.[^"\\]*)*"|\[[^]\\]*(?:\\.[^]\\]*)*\]|\S+'
)


@commands('gcs', 'comp')
@example('%gcs hola mundo')
def gcs(bot, trigger):
    """Compara el número de resultados de búsqueda"""
    if not trigger.group(2):
        return bot.reply("No hay nada a comparar. Ayuda: %help gcs")
    queries = r_query.findall(trigger.group(2))
    if len(queries) > 6:
        return bot.reply('Lo siento, solo puedo comparar 6 cosas.')

    results = []
    for i, query in enumerate(queries):
        query = query.strip('[]')
        n = int((formatnumber(google_count(query)) or '0').replace(',', ''))
        results.append((n, query))
        if i >= 2:
            time.sleep(0.25)
        if i >= 4:
            time.sleep(0.25)

    results = [(term, n) for (n, term) in reversed(sorted(results))]
    reply = ', '.join('%s (%s)' % (t, formatnumber(n)) for (t, n) in results)
    bot.say(reply)

r_bing = re.compile(r'<h3><a href="([^"]+)"')


def bing_search(query, lang='es-ES'):
    base = 'http://www.bing.com/search?mkt=%s&q=' % lang
    bytes = web.get(base + query)
    m = r_bing.search(bytes)
    if m:
        return m.group(1)

r_duck = re.compile(r'nofollow" class="[^"]+" href="(.*?)">')


def duck_search(query):
    query = query.replace('!', '')
    uri = 'http://duckduckgo.com/html/?q=%s&kl=uk-en' % query
    bytes = web.get(uri)
    if 'web-result"' in bytes: #filter out the adds on top of the page
        bytes = bytes.split('web-result"')[1]
    m = r_duck.search(bytes)
    if m:
        return web.decode(m.group(1))


def duck_api(query):
    if '!bang' in query.lower():
        return 'https://duckduckgo.com/bang.html'

    uri = 'http://api.duckduckgo.com/?q=%s&format=json&no_html=1&no_redirect=1' % query
    results = json.loads(web.get(uri))
    if results['Redirect']:
        return results['Redirect']
    else:
        return None


@commands('duck', 'ddg')
@example('%duck privacidad o %duck !mcwiki obsidiana')
def duck(bot, trigger):
    """Busca en Duck Duck Go! un resultado."""
    query = trigger.group(2)
    if not query:
        return bot.reply('¿Qué buscar protegiendo tu privacidad?')

    #If the API gives us something, say it and stop
    result = duck_api(query)
    if result:
        bot.reply(result)
        return

    #Otherwise, look it up on the HTMl version
    uri = duck_search(query)

    if uri:
        bot.reply(uri)
        #bot.memory['last_seen_url'][trigger.sender] = uri
    else:
        bot.reply("No hay resultados para '%s'." % query)


@commands('search', 'buscar')
@example('%search DreamBot GitHub')
def search(bot, trigger):
    """Busca en Google, Bing, and Duck Duck Go!"""
    if not trigger.group(2):
        return bot.reply('¿Que hay que buscar amigo?')
    query = trigger.group(2)
    gu = google_search(query) or '-'
    bu = bing_search(query) or '-'
    du = duck_search(query) or '-'

    if (gu == bu) and (bu == du):
        result = '%s (Google, Bing, Duck)' % gu
    elif (gu == bu):
        result = '%s (Google, Bing), %s (Duck)' % (gu, du)
    elif (bu == du):
        result = '%s (Bing, Duck), %s (Google)' % (bu, gu)
    elif (gu == du):
        result = '%s (Google, Duck), %s (Bing)' % (gu, bu)
    else:
        if len(gu) > 200:
            gu = '(enlace demasiado largo)'
        if len(bu) > 150:
            bu = '(enlace demasiado largo)'
        if len(du) > 150:
            du = '(enlace demasiado largo)'
        result = '%s (Google), %s (Bing), %s (Duck)' % (gu, bu, du)

    bot.reply(result)


@commands('suggest', 'autocomplementar', 'autotab')
def suggest(bot, trigger):
    """Autocomplementa alguna frase especificada."""
    if not trigger.group(2):
        return bot.reply("No hay nada por buscar.")
    query = trigger.group(2)
    uri = 'http://websitedev.de/temp-bin/suggest.pl?q='
    answer = web.get(uri+query.replace('+', '%2B')).replace('Perhaps', 'Resultados para')
    if answer:
        bot.say(answer)
    else:
        bot.reply('Lo siento, no encontré nada.')
