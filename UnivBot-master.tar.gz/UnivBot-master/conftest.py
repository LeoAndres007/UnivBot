# This file lists files which should be ignored by pytest
collect_ignore = ["setup.py", "UnivBot.py", "UnivBot/modules/ipython.py"]
